//Project by Georgy Loriya and Jinhao Chen

#include <iostream>
#include <stdlib.h>
#include <time.h>
using namespace std;

int hexagon[6][6];

bool Lose(int start, int end)
{
	for (int i = 0; i < 6; i++)
	{
		if (start == i || end == i) {
			break;
		}
		if (hexagon[start][i] == 2 && hexagon[end][i] == 2) {
			return true;
		}
	}
	return false;
}

int Lost()
{
	//Check if the player has connected a triangle
	for (int i = 0; i < 6; i++)
	{
		for (int j = i + 1; j < 6; j++)
		{
			if (hexagon[i][j] == 0) {
				break;
			}
			for (int k = 0; k < 6; k++)
			{
				if (k == i || k == j) {
					break;
				}
				if (hexagon[i][j] == hexagon[i][k] && hexagon[i][k] == hexagon[j][k])
				{
					if (hexagon[i][j] == 1) {
						cout << "You connected a triangle from vertices " << i + 1 << ", " << j + 1 << ", and " << k + 1 << ". You lost.";
					}
					else {
						cout << "The computer connected a triangle from vertices " << i + 1 << ", " << j + 1 << ", and " << k + 1 << ". You won!";
					}
					return hexagon[i][j];
				}
			}
		}
	}
	return 0;
}

void UserTurn()
{
	//Declare start and end points
	int start, end;
	//Take input from teh user
	cout << "It is your turn." << endl;
	cout << "What vertex would you like to start your edge at? ";
	cin >> start;
	cout << "What vertex would you like to end your edge at? ";
	cin >> end;
	//Validate the input
	if (start == end)
	{
		cout << "You can't start and end at the same vertex." << endl;
		UserTurn();
	}
	else if (start < 1 || start > 6 || end < 1 || end > 6)
	{
		cout << "Vertices must be between 1 and 6. Try again." << endl;
		UserTurn();
	}
	else if (hexagon[start - 1][end - 1] == 0)
	{
		hexagon[start - 1][end - 1] = 1;
		hexagon[end - 1][start - 1] = 1;
		cout << "You have connected vertices " << start << " and " << end << "." << endl;
	}
	else
	{
		cout << "Those vertices have already been connected by an edge. Try a different edge." << endl;
		UserTurn();
	}
}

void PCTurn(){
	for (int i = 0; i < 6; i++)
	{
		for (int j = i + 1; j < 6; j++)
		{
			if (hexagon[i][j] == 0)
			{
				if (Lose(i, j)) {
					break;
				}
				hexagon[i][j] = 2;
				hexagon[j][i] = 2;
				cout << "Computer connected vertices " << i + 1 << " and " << j + 1 << " together." << endl;
				i = 10;
				j = 10;
			}

		}
		// Check and find the option that does not lead to loosing the game
		if (i == 5)
		{
			for (int i = 0; i < 6; i++)
			{
				for (int j = 0; j < 6; j++)
				{
					if (i == j) {
						break;
					}
					if (hexagon[i][j] == 0)
					{
						hexagon[i][j] = 2;
						hexagon[j][i] = 2;
						cout << "Computer connected vertices " << i + 1 << " and " << j + 1 << " together." << endl;
						i = 10;
						j = 10;
					}

				}
			}
		}
	}
}

int main()
{
	for (int i = 0; i < 6; i++)
	{
		for (int j = 0; j < 6; j++)
		{
			hexagon[i][j] = 0;
		}
	}
	int i = 0;
	while (i != 1 && i != 2)
	{
		cout << "Enter 1 to be player 1 and go first, 2 to be player 2 and go second." << endl;
		cin >> i;
	}
	if (i == 1)
	{
		while (Lost() == 0)
		{
			UserTurn();
			if (Lost() == 1)
				break;
			PCTurn();
		}
	}
	else
	{
		while (Lost() == 0)
		{
			PCTurn();
			if (Lost() == 2)
				break;
			UserTurn();
		}
	}

}
/*
Introduction to AI: Final Project
Jinhao Chen
German Ruiz
Georgy Loriya
*/
#include <iostream>
using namespace std;
//Array containing the pawns' locations. [3] = pawns, [4]: 0 = player's rows, 1 = player's columns, 2 = computer's rows, 3 = computer's columns
int pawnLocations[3][4] = { 4, 0, 0, 0, 4, 1, 0, 1, 4, 2, 0, 2 };
char playerPawnsChars[3] = { '1', '2', '3' }; //Used to identify the pawn on the board by number.
char computer, player; //computer and player are assigned B and W to represent their color pawns.
int maxDepth = 5; //Max depth for minimax search.
int bestMovePawn, bestMoveOption; //Pawn and move selected by the minimax algorithm.

								  //Prints the board. Computer pawns are all represented by its color, player pawns by their numbers.
void Dosplay_Board()
{
	char board[3][5];
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			board[j][i] = ' ';
		}
	}
	for (int i = 0; i < 3; i++)
	{
		board[pawnLocations[i][1]][pawnLocations[i][0]] = playerPawnsChars[i];
		board[pawnLocations[i][3]][pawnLocations[i][2]] = computer;
	}
	cout << "---------------------" << endl;
	for (int i = 0; i < 5; i++)
	{
		cout << "|";
		for (int j = 0; j < 3; j++)
		{
			cout << " " << board[j][i] << " |";
		}
		cout << endl << "---------------------" << endl;
	}
}

//Asks for the player to pick white or black, assigns correct values to char computer and player.
void Assign_Players()
{
	cout << "Would you like to play as the white or black pawns? White goes first. (Enter b for black, w for white)" << endl;
	cin >> player;
	while (cin.get() != '\n');
	if (player == 'b' || player == 'B')
	{
		computer = 'W';
		player = 'B';
	}
	else if (player == 'w' || player == 'W')
	{
		computer = 'B';
		player = 'W';
	}
	else
	{
		cout << "Invalid input. Enter either a 'b' for black, or a 'w' for white." << endl;
	}
}

//Input is the number of the pawn, and who owns it (-1 for player, 1 for computer), returns whether it can move forward.
bool Can_Move_Forward(int pawn, int pawnOwner, int locations[3][4] = pawnLocations)
{
	if (locations[pawn - 1][pawnOwner + 1] == -1)
		return false;
	int row = locations[pawn - 1][pawnOwner + 1];
	int col = locations[pawn - 1][pawnOwner + 2];
	for (int i = 0; i < 3; i++)
	{
		if ((locations[i][pawnOwner + 1] == row + pawnOwner && locations[i][pawnOwner + 2] == col) ||
			(locations[i][-1 * pawnOwner + 1] == row + pawnOwner && locations[i][-1 * pawnOwner + 2] == col))
			return false;
	}
	return true;
}

//Input is the number of the pawn, and who owns it (-1 for player, 1 for computer), returns whether it can capture an enemy pawn to the left.
bool Can_Capture_Left(int pawn, int pawnOwner, int locations[3][4] = pawnLocations)
{
	int row = locations[pawn - 1][pawnOwner + 1];
	int col = locations[pawn - 1][pawnOwner + 2];
	if (locations[pawn - 1][pawnOwner + 1] == -1)
		return false;
	if (col == 0)
		return false;
	for (int i = 0; i < 3; i++)
	{
		if (locations[i][-1 * pawnOwner + 1] == row + pawnOwner && locations[i][-1 * pawnOwner + 2] == col - 1)
			return true;
	}
	return false;
}

//Input is the number of the pawn, and who owns it (-1 for player, 1 for computer), returns whether it can capture an enemy pawn to the right.
bool Can_Capture_Right(int pawn, int pawnOwner, int locations[3][4] = pawnLocations)
{
	int row = locations[pawn - 1][pawnOwner + 1];
	int col = locations[pawn - 1][pawnOwner + 2];
	if (locations[pawn - 1][pawnOwner + 1] == -1)
		return false;
	if (col == 4)
		return false;
	for (int i = 0; i < 3; i++)
	{
		if (locations[i][-1 * pawnOwner + 1] == row + pawnOwner && locations[i][-1 * pawnOwner + 2] == col + 1)
			return true;
	}
	return false;
}

//Input is the number of the pawn, and who owns it (-1 for player, 1 for computer), moves the pawn forward (if able).
void moveForward(int pawn, int pawnOwner, int locations[3][4] = pawnLocations)
{
	if (Can_Move_Forward(pawn, pawnOwner, locations))
		locations[pawn - 1][pawnOwner + 1] += pawnOwner;
}

//Input is the number of the pawn, and who owns it (-1 for player, 1 for computer), captures the enemy pawn to the left (if able).
void Capture_Left(int pawn, int pawnOwner, int locations[3][4] = pawnLocations)
{
	if (Can_Capture_Left(pawn, pawnOwner, locations))
	{
		int col = locations[pawn - 1][pawnOwner + 2];
		int row = locations[pawn - 1][pawnOwner + 1];
		locations[pawn - 1][pawnOwner + 1] += pawnOwner;
		locations[pawn - 1][pawnOwner + 2]--;
		for (int i = 0; i < 3; i++)
		{
			if (locations[i][-1 * pawnOwner + 1] == row + pawnOwner && locations[i][-1 * pawnOwner + 2] == col - 1)
			{
				locations[i][-1 * pawnOwner + 1] = -1;
				locations[i][-1 * pawnOwner + 2] = -1;
			}
		}
	}
}

//Input is the number of the pawn, and who owns it (-1 for player, 1 for computer), captures the enemy pawn to the right (if able).
void Capture_Right(int pawn, int pawnOwner, int locations[3][4] = pawnLocations)
{
	if (Can_Capture_Right(pawn, pawnOwner, locations))
	{
		int col = locations[pawn - 1][pawnOwner + 2];
		int row = locations[pawn - 1][pawnOwner + 1];
		locations[pawn - 1][pawnOwner + 1] += pawnOwner;
		locations[pawn - 1][pawnOwner + 2]++;
		for (int i = 0; i < 3; i++)
		{
			if (locations[i][-1 * pawnOwner + 1] == row + pawnOwner && locations[i][-1 * pawnOwner + 2] == col + 1)
			{
				locations[i][-1 * pawnOwner + 1] = -1;
				locations[i][-1 * pawnOwner + 2] = -1;
			}
		}
	}
}

//Asks the user to choose a pawn to move, returns the number of the chosen pawn.
int Choose_Pawn(int locations[3][4] = pawnLocations)
{
	char input = ' ';
	Dosplay_Board();
	cout << "Which pawn do you want to move? Enter the pawn's number to select it. (1-3)" << endl;
	cin >> input;
	while (cin.get() != '\n');
	for (int i = 0; i < 3; i++)
	{
		if (playerPawnsChars[i] == input)
		{
			if (locations[i][0] != -1)
			{
				if (Can_Move_Forward(i + 1, -1, locations) || Can_Capture_Left(i + 1, -1, locations) || Can_Capture_Right(i + 1, -1, locations))
				{
					return i + 1;
				}
				else
				{
					cout << "That pawn has no place to move." << endl;
					return -1;
				}
			}
			else
			{
				cout << "That pawn has already been taken." << endl;
				return -1;
			}
		}
	}
	cout << "Invalid input, try again." << endl;
	return -1;
}

//Checks conditions to see if the player has lost.
bool Lost(int locations[3][4] = pawnLocations)
{
	bool canMove = false;
	bool remainingPawns = false;
	for (int i = 0; i < 3; i++)
	{
		if (locations[i][2] == 4)
		{
			Dosplay_Board();
			cout << "The computer got a pawn to the end. You lose." << endl;
			return true;
		}
		if (!remainingPawns)
		{
			if (locations[i][0] != -1)
				remainingPawns = true;
			else
				continue;
		}
		if (!canMove)
		{
			if (Can_Move_Forward(i + 1, -1, locations) || Can_Capture_Left(i + 1, -1, locations) || Can_Capture_Right(i + 1, -1, locations))
				canMove = true;
		}
	}
	if (!remainingPawns)
	{
		Dosplay_Board();
		cout << "You don't have any pawns left. You lose." << endl;
		return true;
	}
	if (!canMove)
	{
		Dosplay_Board();
		cout << "None of your remaining pawns can move. You lose." << endl;
		return true;
	}
	return false;
}

//Checks conditions to see if the player has won.
bool Won(int locations[3][4] = pawnLocations)
{
	bool canMove = false;
	bool remainingPawns = false;
	for (int i = 0; i < 3; i++)
	{
		if (locations[i][0] == 0)
		{
			Dosplay_Board();
			cout << "You got a pawn to the end! You won!" << endl;
			return true;
		}
		if (!remainingPawns)
		{
			if (locations[i][2] != -1)
				remainingPawns = true;
			else
				continue;
		}
		if (!canMove)
		{
			if (Can_Move_Forward(i + 1, 1, locations) || Can_Capture_Left(i + 1, 1, locations) || Can_Capture_Right(i + 1, 1, locations))
				canMove = true;
		}
	}
	if (!remainingPawns)
	{
		Dosplay_Board();
		cout << "The computer doesn't have any pawns left! You won!" << endl;
		return true;
	}
	if (!canMove)
	{
		Dosplay_Board();
		cout << "None of the computer's remaining pawns can move! You won!" << endl;
		return true;
	}
	return false;
}

//Checks conditions to see if the computer would win.
bool Will_Win(int locations[3][4] = pawnLocations)
{
	bool canMove = false;
	bool remainingPawns = false;
	for (int i = 0; i < 3; i++)
	{
		if (locations[i][2] == 4)
			return true;
		if (!remainingPawns)
		{
			if (locations[i][0] != -1)
				remainingPawns = true;
			else
				continue;
		}
		if (!canMove)
		{
			if (Can_Move_Forward(i + 1, -1, locations) || Can_Capture_Left(i + 1, -1, locations) || Can_Capture_Right(i + 1, -1, locations))
				canMove = true;
		}
	}
	if (!remainingPawns || !canMove)
		return true;
	return false;
}

//Checks conditions to see if the computer would lose.
bool Will_Lose(int locations[3][4] = pawnLocations)
{
	bool canMove = false;
	bool remainingPawns = false;
	for (int i = 0; i < 3; i++)
	{
		if (locations[i][0] == 0)
			return true;
		if (!remainingPawns)
		{
			if (locations[i][2] != -1)
				remainingPawns = true;
			else
				continue;
		}
		if (!canMove)
		{
			if (Can_Move_Forward(i + 1, 1, locations) || Can_Capture_Left(i + 1, 1, locations) || Can_Capture_Right(i + 1, 1, locations))
				canMove = true;
		}
	}
	if (!remainingPawns || !canMove)
		return true;
	return false;
}

//The player's turn. From choosing a pawn to choosing where it should move.
void Player_Turn(int locations[3][4] = pawnLocations)
{
	char input = ' ';
	int pawn = -1;
	cout << "The computer's pawns are shown by " << computer << "." << endl;
	cout << "Your pawns are shown as numbers and can move upwards one space or diagonally forward to take an enemy pawn." << endl;
	while (pawn == -1)
	{
		pawn = Choose_Pawn();
	}
	if (Can_Move_Forward(pawn, -1, locations))
	{
		if (Can_Capture_Left(pawn, -1, locations))
		{
			if (Can_Capture_Right(pawn, -1, locations))
			{
				cout << "Pawn " << pawn << " can move forward or take either opponent diagonal to it." << endl;
				while (input == ' ')
				{
					cout << "Enter 1 to move forward, 2 to take the left enemy pawn, 3 to take the right enemy pawn, or 0 to pick a different pawn." << endl;
					cin >> input;
					while (cin.get() != '\n');
					if (input == '0')
						pawn = -1;
					else if (input == '1')
						moveForward(pawn, -1, locations);
					else if (input == '2')
						Capture_Left(pawn, -1, locations);
					else if (input == '3')
						Capture_Right(pawn, -1, locations);
					else
					{
						cout << "Invalid input." << endl;
						input = ' ';
					}
				}
			}
			else
			{
				cout << "Pawn " << pawn << " can move forward or take the opponent diagonal to it." << endl;
				while (input == ' ')
				{
					cout << "Enter 1 to move forward, 2 to take the left enemy pawn, or 0 to pick a different pawn." << endl;
					cin >> input;
					while (cin.get() != '\n');
					if (input == '0')
						pawn = -1;
					else if (input == '1')
						moveForward(pawn, -1, locations);
					else if (input == '2')
						Capture_Left(pawn, -1, locations);
					else
					{
						cout << "Invalid input." << endl;
						input = ' ';
					}
				}
			}
		}
		else
		{
			if (Can_Capture_Right(pawn, -1, locations))
			{
				cout << "Pawn " << pawn << " can move forward or take the opponent diagonal to it." << endl;
				while (input == ' ')
				{
					cout << "Enter 1 to move forward, 3 to take the right enemy pawn, or 0 to pick a different pawn." << endl;
					cin >> input;
					while (cin.get() != '\n');
					if (input == '0')
						pawn = -1;
					else if (input == '1')
						moveForward(pawn, -1, locations);
					else if (input == '3')
						Capture_Right(pawn, -1, locations);
					else
					{
						cout << "Invalid input." << endl;
						input = ' ';
					}
				}
			}
			else
			{
				cout << "Pawn " << pawn << " can only move forward." << endl;
				while (input == ' ')
				{
					cout << "Enter 1 to move forward or 0 to pick a different pawn." << endl;
					cin >> input;
					while (cin.get() != '\n');
					if (input == '0')
						pawn = -1;
					else if (input == '1')
						moveForward(pawn, -1, locations);
					else
					{
						cout << "Invalid input." << endl;
						input = ' ';
					}
				}
			}
		}
	}
	else
	{
		if (Can_Capture_Left(pawn, -1, locations))
		{
			if (Can_Capture_Right(pawn, -1, locations))
			{
				cout << "Pawn " << pawn << " can take either opponent diagonal to it." << endl;
				while (input == ' ')
				{
					cout << "Enter 2 to take the left enemy pawn, 3 to take the right enemy pawn, or 0 to pick a different pawn." << endl;
					cin >> input;
					while (cin.get() != '\n');
					if (input == '0')
						pawn = -1;
					else if (input == '2')
						Capture_Left(pawn, -1, locations);
					else if (input == '3')
						Capture_Right(pawn, -1, locations);
					else
					{
						cout << "Invalid input." << endl;
						input = ' ';
					}
				}
			}
			else
			{
				cout << "Pawn " << pawn << " can only take the opponent diagonal to it." << endl;
				while (input == ' ')
				{
					cout << "Enter 2 to take the left enemy pawn or 0 to pick a different pawn." << endl;
					cin >> input;
					while (cin.get() != '\n');
					if (input == '0')
						pawn = -1;
					else if (input == '2')
						Capture_Left(pawn, -1, locations);
					else
					{
						cout << "Invalid input." << endl;
						input = ' ';
					}
				}
			}
		}
		else
		{
			if (Can_Capture_Right(pawn, -1, locations))
			{
				cout << "Pawn " << pawn << " can only take the opponent diagonal to it." << endl;
				while (input == ' ')
				{
					cout << "Enter 3 to take the right enemy pawn or 0 to pick a different pawn." << endl;
					cin >> input;
					while (cin.get() != '\n');
					if (input == '0')
						pawn = -1;
					else if (input == '3')
						Capture_Right(pawn, -1, locations);
					else
					{
						cout << "Invalid input." << endl;
						input = ' ';
					}
				}
			}
			else
			{
				cout << "Pawn " << pawn << " can't move. Please pick a different pawn." << endl;
				pawn = -1;
			}
		}
	}
	if (pawn == -1)
		Player_Turn(locations);
}

//Minimax algorithm to determine the best move for the computer to take.
int Best_Move(int pawnOwner = 1, int locations[3][4] = pawnLocations, int depth = maxDepth)
{
	if (Will_Win(locations))
		return 500;
	if (Will_Lose(locations))
		return -500;
	if (depth == 0)
		return 0;
	int tempLocations[3][4];
	int value, bestValue;
	if (pawnOwner == -1)
	{
		value = 10000;
		bestValue = 10000;
		for (int i = 0; i < 3; i++)
		{
			if (locations[i][0] == -1)
				continue;
			if (Can_Capture_Left(i + 1, -1, locations))
			{
				for (int i = 0; i < 3; i++)
				{
					for (int j = 0; j < 4; j++)
					{
						tempLocations[i][j] = locations[i][j];
					}
				}
				Capture_Left(i + 1, -1, tempLocations);
				value = Best_Move(1, tempLocations, depth - 1);
				if (value < -500)
					value = -499;
				else
					value += -1 * (4 - tempLocations[i][0]) - 20;
				if (value < bestValue)
				{
					bestValue = value;
				}
			}
			if (Can_Capture_Right(i + 1, -1, locations))
			{
				for (int i = 0; i < 3; i++)
				{
					for (int j = 0; j < 4; j++)
					{
						tempLocations[i][j] = locations[i][j];
					}
				}
				Capture_Right(i + 1, -1, tempLocations);
				value = Best_Move(1, tempLocations, depth - 1);
				if (value < -500)
					value = -499;
				else
					value += -1 * (4 - tempLocations[i][0]) - 20;
				if (value < bestValue)
				{
					bestValue = value;
				}
			}
			if (Can_Move_Forward(i + 1, -1, locations))
			{
				for (int i = 0; i < 3; i++)
				{
					for (int j = 0; j < 4; j++)
					{
						tempLocations[i][j] = locations[i][j];
					}
				}
				moveForward(i + 1, -1, tempLocations);
				value = Best_Move(1, tempLocations, depth - 1);
				if (value < -500)
					value = -499;
				else
					value += -1 * (4 - tempLocations[i][0]);
				if (value < bestValue)
				{
					bestValue = value;
				}
			}
		}
	}
	else if (pawnOwner == 1)
	{
		value = -10000;
		bestValue = -10000;
		for (int i = 0; i < 3; i++)
		{
			if (locations[i][2] == -1)
				continue;
			if (Can_Capture_Left(i + 1, 1, locations))
			{
				for (int i = 0; i < 3; i++)
				{
					for (int j = 0; j < 4; j++)
					{
						tempLocations[i][j] = locations[i][j];
					}
				}
				Capture_Left(i + 1, 1, tempLocations);
				value = Best_Move(-1, tempLocations, depth - 1);
				if (value > 500)
					value = 499;
				else
					value += tempLocations[i][2] + 20;
				if (value > bestValue)
				{
					bestValue = value;
					if (depth == maxDepth)
					{
						bestMovePawn = i;
						bestMoveOption = 2;
					}
				}
			}
			if (Can_Capture_Right(i + 1, 1, locations))
			{
				for (int i = 0; i < 3; i++)
				{
					for (int j = 0; j < 4; j++)
					{
						tempLocations[i][j] = locations[i][j];
					}
				}
				Capture_Right(i + 1, 1, tempLocations);
				value = Best_Move(-1, tempLocations, depth - 1);
				if (value > 500)
					value = 499;
				else
					value += tempLocations[i][2] + 20;
				if (value > bestValue)
				{
					bestValue = value;
					if (depth == maxDepth)
					{
						bestMovePawn = i;
						bestMoveOption = 3;
					}
				}
			}
			if (Can_Move_Forward(i + 1, 1, locations))
			{
				for (int i = 0; i < 3; i++)
				{
					for (int j = 0; j < 4; j++)
					{
						tempLocations[i][j] = locations[i][j];
					}
				}
				moveForward(i + 1, 1, tempLocations);
				value = Best_Move(-1, tempLocations, depth - 1);
				if (value > 500)
					value = 499;
				else
					value += tempLocations[i][2];
				if (value > bestValue)
				{
					bestValue = value;
					if (depth == maxDepth)
					{
						bestMovePawn = i;
						bestMoveOption = 1;
					}
				}
			}
		}
	}
	else
	{
		cout << "ERROR: int pawnOwner should be either -1 or 1." << endl;
		return false;
	}
	return bestValue;
}

//The computer's turn.
void PC_turn(int locations[3][4] = pawnLocations)
{
	int temp = Best_Move();
	if (bestMoveOption == 1)
		moveForward(bestMovePawn + 1, 1, locations);
	else if (bestMoveOption == 2)
		Capture_Left(bestMovePawn + 1, 1, locations);
	else if (bestMoveOption == 3)
		Capture_Right(bestMovePawn + 1, 1, locations);
	else
	{
		for (int i = 0; i < 3; i++)
		{
			if (locations[i][2] == -1)
				continue;
			else if (Can_Move_Forward(i + 1, 1, locations))
			{
				moveForward(i + 1, 1, locations);
				break;
			}
			else if (Can_Capture_Left(i + 1, 1, locations))
			{
				Capture_Left(i + 1, 1, locations);
				break;
			}
			else if (Can_Capture_Right(i + 1, 1, locations))
			{
				Capture_Right(i + 1, 1, locations);
				break;
			}
			else
				continue;
		}
	}
}

//Main function: Assign white/black, loop through alternating turns until game has ended.
int main()
{
	while (!computer)
		Assign_Players();
	if (computer == 'W')
		PC_turn();
	while (1)
	{
		Player_Turn();
		if (Won())
			break;
		PC_turn();
		if (Lost())
			break;
	}
}
